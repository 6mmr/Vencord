@echo off
setlocal DisableDelayedExpansion
set "AFKP_TARGET=%USERPROFILE%\Mc5mr-Vencord"
set "AFKP_PATCH=%~dp0AFKPanel.patch"
echo AFK Panel by Mc5mr - Windows setup
where git >nul 2>&1
if errorlevel 1 goto missing_git
where node >nul 2>&1
if errorlevel 1 goto missing_node
node -e "process.exit(Number(process.versions.node.split('.')[0]) >= 22 ? 0 : 1)"
if errorlevel 1 goto missing_node
where pnpm >nul 2>&1
if errorlevel 1 goto missing_pnpm
if not exist "%AFKP_PATCH%" goto missing_patch
if exist "%AFKP_TARGET%" goto existing_folder

echo Downloading the source repository...
git clone --no-checkout https://github.com/6mmr/Vencord.git "%AFKP_TARGET%"
if errorlevel 1 goto failed
cd /d "%AFKP_TARGET%"
if errorlevel 1 goto failed
git checkout -b mc5mr-afk-panel b21a42f50be0f7e9dbc21c8209f521f2828a375b
if errorlevel 1 goto failed
git apply --check "%AFKP_PATCH%"
if errorlevel 1 goto failed
git apply "%AFKP_PATCH%"
if errorlevel 1 goto failed

echo Installing build dependencies...
call pnpm install --frozen-lockfile
if errorlevel 1 goto failed
echo Building Vencord with AFK Panel...
call pnpm build
if errorlevel 1 goto failed
echo.
echo Build complete. Read AFKPANEL_AR.md for service setup.
echo To install in Discord, open CMD and run:
echo cd /d "%AFKP_TARGET%"
echo pnpm inject
echo Then select Discord Canary if that is your client.
echo Source changes are local. The script does not publish to GitHub.
pause
exit /b 0

:missing_git
echo Install Git for Windows, reopen this script, and try again.
goto stopped
:missing_node
echo Node.js 22 or newer is required. Reopen this script after installing it.
goto stopped
:missing_pnpm
echo pnpm is required. Install it, reopen this script, and try again.
goto stopped
:missing_patch
echo AFKPanel.patch was not found. Extract the entire ZIP first.
goto stopped
:existing_folder
echo The destination already exists:
echo "%AFKP_TARGET%"
echo Setup stopped to preserve your files. See AFKPANEL_AR.md for manual setup.
goto stopped
:failed
echo A command failed. Read the error above before retrying.
echo Any downloaded project remains at "%AFKP_TARGET%".
:stopped
pause
exit /b 1
